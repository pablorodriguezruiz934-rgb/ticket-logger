package org.alixar.daw2.pablo.dwese_ticket_logger_webapp.entity;

public class Transformador {
}
