package org.iesalixar.daw2.pabloRodriguezRuiz.dao;
/**
 * Pablo Rodriguez Ruiz
 */

import org.iesalixar.daw2.pabloRodriguezRuiz.entity.Province;
import java.sql.SQLException;
import java.util.List;


public interface ProvinceDAO {
    /**
     *
     * @return
     * @throws SQLException
     * Lista las provincias insertadas en la base de datos
     */
    List<Province> listAllProvinces() throws SQLException;

    /**
     *
     * @param region
     * @throws SQLException
     * Inserta una provincia en la base de datos
     */
    void insertProvince(Province region) throws SQLException;

    /**
     *
     * @param region
     * @throws SQLException
     * Actualiza los datos de una provincia que ya existe
     */
    void updateProvince(Province region) throws SQLException;

    /**
     *
     * @param id
     * @throws SQLException
     * Elimina una provincia que ya existe
     */
    void deleteProvince(int id) throws SQLException;

    /**
     *
     * @param id
     * @return
     * @throws SQLException
     * Hace una consulta a la base de datos donde el parametro de busqueda en el where es el id
     */
    Province getProvinceById(int id) throws SQLException;

    /**
     *
     * @param code
     * @return
     * @throws SQLException
     * Comprueba si existe una provincia
     */
    boolean existsProvinceByCode(String code) throws SQLException;
    boolean existsProvinceByCodeAndNotId(String code, int id) throws SQLException;
}