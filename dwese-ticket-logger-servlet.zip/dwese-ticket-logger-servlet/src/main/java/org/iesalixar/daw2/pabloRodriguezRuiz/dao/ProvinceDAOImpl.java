
        package org.iesalixar.daw2.pabloRodriguezRuiz.dao;

        import java.sql.*;
        import java.util.ArrayList;
        import java.util.List;
        import org.iesalixar.daw2.pabloRodriguezRuiz.dao.DatabaseConnectionManager;
        import org.iesalixar.daw2.pabloRodriguezRuiz.dao.ProvinceDAO;
        import org.iesalixar.daw2.pabloRodriguezRuiz.entity.Province;

        /**
         * Pablo Rodriguez Ruiz
         */
        public class ProvinceDAOImpl implements ProvinceDAO {
            /**
             *
             * @return
             * @throws SQLException
             * Lista las provincias insertadas en la base de datos
             */
            public List<Province> listAllProvinces() throws SQLException {
                List<Province> provinces = new ArrayList<>();
                String query = "SELECT * FROM provinces";
                // Obtener una nueva conexión para cada operación
                try (Connection connection = DatabaseConnectionManager.getConnection();
                     Statement statement = connection.createStatement();
                     ResultSet resultSet = statement.executeQuery(query)) {
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String code = resultSet.getString("code");
                        String name = resultSet.getString("name");
                        int id_region = resultSet.getInt("id_region");
                        provinces.add(new Province(id, code, name, id_region));
                    }
                }
                return provinces;
            }
            /**
             *
             * @param
             * @throws SQLException
             * Inserta una provincia en la base de datos
             */
            public void insertProvince(Province province) throws SQLException {
                String query = "INSERT INTO provinces (code, name, id_region) VALUES (?, ?, ?)";
                try (Connection connection = DatabaseConnectionManager.getConnection();
                     PreparedStatement preparedStatement =
                             connection.prepareStatement(query)) {
                    preparedStatement.setString(1, province.getCode());
                    preparedStatement.setString(2, province.getName());
                    preparedStatement.setInt(3, province.getId_region());
                    preparedStatement.executeUpdate();
                }
            }
            /**
             *
             * @param
             * @throws SQLException
             * Actualiza los datos de una provincia que ya existe
             */
            public void updateProvince(Province province) throws SQLException {
                String query = "UPDATE provinces SET code = ?, name = ?, id_region = ? WHERE id = ?";
                try (Connection connection = DatabaseConnectionManager.getConnection();
                     PreparedStatement preparedStatement =
                             connection.prepareStatement(query)) {
                    preparedStatement.setString(1, province.getCode());
                    preparedStatement.setString(2, province.getName());
                    preparedStatement.setInt(3, province.getId_region());
                    preparedStatement.setInt(4, province.getId());
                    preparedStatement.executeUpdate();
                }
            }
            /**
             *
             * @param id
             * @throws SQLException
             * Elimina una provincia que ya existe
             */
            public void deleteProvince(int id) throws SQLException {
                String query = "DELETE FROM provinces WHERE id = ?";
                try (Connection connection = DatabaseConnectionManager.getConnection();
                     PreparedStatement preparedStatement =
                             connection.prepareStatement(query)) {
                    preparedStatement.setInt(1, id);
                    preparedStatement.executeUpdate();
                }
            }
            /**
             *
             * @param id
             * @return
             * @throws SQLException
             * Hace una consulta a la base de datos donde el parametro de busqueda en el where es el id
             */
            public Province getProvinceById(int id) throws SQLException {
                String query = "SELECT * FROM provinces WHERE id = ?";
                Province province = null;
                try (Connection connection = DatabaseConnectionManager.getConnection();
                     PreparedStatement preparedStatement =
                             connection.prepareStatement(query)) {
                    preparedStatement.setInt(1, id);
                    ResultSet resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        String code = resultSet.getString("code");
                        String name = resultSet.getString("name");
                        int id_region = resultSet.getInt("id_region");
                        province = new Province(id, code, name, id_region);
                    }
                }
                return province;
            }

            @Override
            /**
             *
             * @param code
             * @return
             * @throws SQLException
             * Comprueba si existe una provincia
             */
            public boolean existsProvinceByCode(String code) throws SQLException {
                String sql = "SELECT COUNT(*) FROM provinces WHERE UPPER(code) = ?";
                try (Connection connection = DatabaseConnectionManager.getConnection())
                {
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, code.toUpperCase());
                    try (ResultSet resultSet = statement.executeQuery()) {
                        resultSet.next();
                        return resultSet.getInt(1) > 0;
                    }
                }
            }

            @Override
            public boolean existsProvinceByCodeAndNotId(String code, int id) throws
                    SQLException {
                String sql = "SELECT COUNT(*) FROM provinces WHERE UPPER(code) = ? AND id != ?";
                try (Connection connection = DatabaseConnectionManager.getConnection())
                {
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, code.toUpperCase());
                    statement.setInt(2, id);
                    try (ResultSet resultSet = statement.executeQuery()) {
                        resultSet.next();
                        return resultSet.getInt(1) > 0;
                    }
                }
            }
        }