package org.iesalixar.daw2.pabloRodriguezRuiz.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad que representa una provincia.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
/**
 * Pablo Rodriguez Ruiz
 */
public class Province {

    /** Identificador único clave primaria autoincremental */
    private int id;

    /** Código único de la provincia  */
    private String code;

    /** Nombre de la provincia  */
    private String name;

    /** Identificador de la Comunidad Autónoma a la que pertenece clave foránea */
    private int id_region;

    /**
     * Constructor sin id, útil para crear provincias nuevas antes de insertarlas
     * @param code      código de la provincia
     * @param name      nombre de la provincia
     * @param id_region id de la Comunidad Autónoma
     */
    public Province(String code, String name, int id_region) {
        this.code = code;
        this.name = name;
        this.id_region = id_region;
    }
}