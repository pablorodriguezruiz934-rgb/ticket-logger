<%@ include file="header.jsp" %>
<h2>Hello world</h2>
<%@ include file="footer.jsp" %>

